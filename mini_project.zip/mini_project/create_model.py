# It creates a model in keras

import numpy as np
import pandas as pd
import tensorflow as tf
import keras

from keras.models import Sequential, model_from_json
from keras.layers import (Conv2D, MaxPooling2D, Dense, Dropout, Flatten,
                    LeakyReLU, Activation)
from keras.optimizers import SGD
from keras import losses
from keras.callbacks import TensorBoard

# Thanks to https://github.com/yhenon/keras-spp for the SPP Layer
from spp.SpatialPyramidPooling import SpatialPyramidPooling
from datetime import datetime

JUMP = 5 # Number of Epochs after we Save Model

def create_model():
  """This module creates an Instance of the Sequential Class in Keras.

  Return:
    model: Instance of the Sequential Class
  """
  time_start = datetime.now()

  model = Sequential()
  model.add(Conv2D(64, (3, 3), padding='same', activation='relu', input_shape=(50, 100, 1)))
  model.add(Conv2D(64, (3, 3), padding='same', activation='relu'))
  model.add(MaxPooling2D(pool_size=(2, 2), strides=2))
  model.add(Conv2D(128, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(128, (3, 3), padding='same', activation='relu'))
  model.add(MaxPooling2D(pool_size=(2, 2), strides=2))
  model.add(Conv2D(256, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(256, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(256, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(256, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(256, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(256, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(512, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(512, (3, 3), padding='same', activation='relu'))
  model.add(Conv2D(512, (3, 3), padding='same', activation='relu'))
  model.add(SpatialPyramidPooling([1, 2, 4])) 
  model.add(Dense(4096, activation='relu'))
  model.add(Dropout(0.5))
  model.add(Dense(4096, activation='relu'))
  model.add(Dropout(0.5))
  model.add(Dense(604, activation='sigmoid'))

  loss = losses.binary_crossentropy
  optimizer = SGD(lr=1e-4, momentum=.9, decay=5e-5)
  model.compile(loss=loss, optimizer=optimizer, metrics=['accuracy'])
  model.summary()
  print ("Time taken to create model: ", datetime.now()-time_start)
    
  return model

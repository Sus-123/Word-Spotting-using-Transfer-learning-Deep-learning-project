# A pretrained model is created and now we are applying Transfer Learning to this model
import numpy as np
import tensorflow as tf
import keras
import pandas as pd

from keras.models import Sequential, Model, model_from_json
from keras.layers import (Conv2D, MaxPooling2D, Dense, Dropout, Flatten, LeakyReLU, Activation)
from keras.layers import *
from keras.optimizers import SGD
from keras import losses
from keras.callbacks import TensorBoard
from keras import layers, models

from keras.applications.vgg16 import VGG16
from keras.models import Model
from keras.layers import Flatten, Dense, Dropout
from keras.layers.normalization import BatchNormalization

import matplotlib.pyplot as plt
import numpy as np
import os

from create_model import create_model
from train import fit_model
from load_data import load_data
from save_load_weight import *
from evaluate import map
from sample_plot import summarize_model

JUMP = 10

phocnet = create_model()   

phocnet = load_model_weight(phocnet)    #load weights from .pkl file

tl_model = Sequential()
#tl_model.add(phocnet)
for layer in phocnet.layers[:-5]: #except dense layers
    tl_model.add(layer)

#Freezing the layers 

for layer in tl_model.layers:
    layer.trainable = False

#Adding new FC layers

#tl_model.add(Conv2D(512, (3, 3), padding='same', activation='relu'))
#tl_model.add(MaxPooling2D(pool_size = (2, 2)))
#tl_model.add(Activation('relu'))
#tl_model.add(Flatten())
tl_model.add(Dense(4096, activation='relu'))
tl_model.add(Dropout(0.5))
tl_model.add(Dense(4096, activation='relu'))
tl_model.add(Dropout(0.5))
tl_model.add(Dense(604, activation='sigmoid'))


tl_model.summary()
loss = losses.binary_crossentropy
optimizer = SGD(lr=1e-4, momentum=.9, decay=5e-5)
tl_model.compile(loss=loss, optimizer=optimizer, metrics=['accuracy'])


'''dataset_name = 'iam_names/phocnet'
data = load_data(dataset_name)       # function to load the input data for training and testing purpose
'''

dataset_name = 'iam_names/trans_learn'
data = load_data(dataset_name)       # function in load_data.py

x_train = data[0]
y_train = data[1]
x_valid = data[3]
y_valid = data[4]
x_test = data[6]
y_test = data[7]

for i in range(0, 10, JUMP):
    tl_model, history = fit_model(tl_model, x_train, y_train, x_valid, y_valid, i) #initial_epoch = i
    save_model_weight(tl_model) # Saves the phocnet_model 
    print ("Model training completed.\n")

summarize_model(tl_model, history, x_train, y_train, x_test, y_test)

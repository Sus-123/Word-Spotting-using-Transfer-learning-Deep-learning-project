# Saving and Loading Models using Pickle
import pandas as pd
def save_model_weight(model):
  weights = model.get_weights()
  df = pd.DataFrame(weights)
  df.to_pickle('saved_models/phoc_weights.pkl')


def load_model_weight(model):
  #This function will load the model weights from the saved model weights.
  df = pd.read_pickle('saved_models/phoc_weights.pkl')
  tmp_weights = df.values
  N = len(tmp_weights)
  weights = []
  for i in range(N):
    weights.append(tmp_weights[i][0])
  model.set_weights(weights)
  return model


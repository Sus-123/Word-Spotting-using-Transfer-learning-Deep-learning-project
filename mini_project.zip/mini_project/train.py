#This trains the model partially and
#returns the partially trained weights

import tensorflow as tf
import keras
from keras.callbacks import TensorBoard

from datetime import datetime

JUMP = 10 # Number of Epochs after we Save Model

def fit_model(model, x_train, y_train, x_valid, y_valid, initial_epoch=0):
  """
  Args:
    model: Instance of the Sequential Class storing the Neural Network
    x_train: Numpy storing the training Images
    y_train: Numpy storing the PHOC Label of the training Images
    x_valid: Numpy storing the Validation Images
    y_valid: Numpy storing the PHOC Labels of Validation Data
    initial_epoch: Starting Epoch of the partial Train (Default: 0)

  Returns:
    model: Instance of the Sequential Class having partially trained model
  """
  tnsbrd = TensorBoard(log_dir='./logs')
  history = model.fit(x_train, y_train, batch_size=10, callbacks=[tnsbrd], 
                      epochs=initial_epoch+JUMP, initial_epoch=initial_epoch,
                      validation_data=(x_valid, y_valid))
  return model, history


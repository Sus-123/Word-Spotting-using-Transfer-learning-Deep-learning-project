# This is the main file to be called initially

from create_model import create_model
from train import fit_model
from load_data import load_data
from save_load_weight import save_model_weight
from evaluate import map
from sample_plot import summarize_model

JUMP = 10 # Number of Epochs after we Save Model

model = create_model()   # function to create the instance of the Sequential Class in keras

dataset_name = 'iam_names/phocnet'
data = load_data(dataset_name)       # function to load the input data for training and testing purpose
x_train = data[0]
y_train = data[1]
x_valid = data[3]
y_valid = data[4]
x_test = data[6]
y_test = data[7]
for i in range(0, 10, JUMP):
    model, history = fit_model(model, x_train, y_train, x_valid, y_valid, i) #trains the model
    save_model_weight(model) # Saves the model 
    print ("Model training completed.\n")

summarize_model(model, history, x_train, y_train, x_test, y_test) #Plot the performance

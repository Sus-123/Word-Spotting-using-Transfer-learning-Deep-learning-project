Please download the words.tgz file of the IAM database.
Or you can store you own dataset in this folder.
